﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CSTest3_AbstractFactoryIThink.Classes
{
    class Client
    {
        public void UseFactories()
        {
            AbstractFactory factory1 = new FactoryType1();
            UseProducts(factory1);

            AbstractFactory factory2 = new FactoryType2();
            UseProducts(factory2);
        }

        private void UseProducts(AbstractFactory factory)
        {
            AbstractProductA productA = factory.CreateProductA();
            AbstractProductB productB = factory.CreateProductB();

            Console.WriteLine(productB.DoSomethingWithProductA(productA));
            Console.ReadKey();
            Console.Clear();
        }
    }
}
