﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CSTest3_AbstractFactoryIThink.Classes
{
    class ProductA1 : AbstractProductA
    {
        public override string DoSomething()
        {
            return "The best product A";
        }
    }
}
