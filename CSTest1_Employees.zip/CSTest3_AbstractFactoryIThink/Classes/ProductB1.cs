﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CSTest3_AbstractFactoryIThink.Classes
{
    class ProductB1 : AbstractProductB
    {
        public override string DoSomething()
        {
            return "The worst product B";
        }

        public override string DoSomethingWithProductA(AbstractProductA productA)
        {
            return $"This products are {productA.DoSomething()} and {DoSomething()}";
        }
    }
}
