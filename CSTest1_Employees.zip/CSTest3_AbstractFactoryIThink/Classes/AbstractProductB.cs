﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CSTest3_AbstractFactoryIThink.Classes
{
    abstract class AbstractProductB
    {
        public abstract string DoSomething();

        public abstract string DoSomethingWithProductA(AbstractProductA productA);
    }
}
