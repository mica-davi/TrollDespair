﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CSTest3_AbstractFactoryIThink
{
    class Program
    {
        static void Main(string[] args)
        {
            //this program is probably the peak of the lack of creativity :)
            Classes.Client client = new Classes.Client();
            client.UseFactories();
        }
    }
}
