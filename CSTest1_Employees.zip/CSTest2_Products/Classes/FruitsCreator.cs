﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CSTest2_Products.Classes
{
    public interface FruitsCreator
    {
        Fruit ProductCreator();
    }
}
