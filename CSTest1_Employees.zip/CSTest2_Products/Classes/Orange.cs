﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CSTest2_Products.Classes
{
    class Orange : Fruit
    {
        public void FruitTaste()
        {
            Console.WriteLine("It tastes like Orange!");
        }
    }
}
