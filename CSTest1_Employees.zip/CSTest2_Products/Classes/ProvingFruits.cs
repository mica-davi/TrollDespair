﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CSTest2_Products.Classes
{
    public static class ProvingFruits
    {
        public static void StartProving()
        {
            Console.Write("What do you want to eat? (Orange/Apple) ");

            string chosenFruit = Console.ReadLine();

            FruitsCreator fruitCreator = null;

            if (chosenFruit == "Orange")
            {
                fruitCreator = new OrangeCreator();
            }
            else if (chosenFruit == "Apple")
            {
                fruitCreator = new AppleCreator();
            }

            if(fruitCreator != null)
                BlindlyProvingFruits(fruitCreator);

            Console.ReadKey();
        }

        static void BlindlyProvingFruits(FruitsCreator creator)
        {
            Fruit fruit = creator.ProductCreator();
            fruit.FruitTaste();
        }
    }
}
